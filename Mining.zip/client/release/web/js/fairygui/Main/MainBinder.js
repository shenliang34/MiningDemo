/** This is an automatically generated class by FairyGUI. Please do not modify it. **/
var Main;
(function (Main) {
    var MainBinder = (function () {
        function MainBinder() {
        }
        MainBinder.bindAll = function () {
            fairygui.UIObjectFactory.setPackageItemExtension(Main.UI_GameUI.URL, Main.UI_GameUI);
        };
        return MainBinder;
    }());
    Main.MainBinder = MainBinder;
})(Main || (Main = {}));
//# sourceMappingURL=MainBinder.js.map