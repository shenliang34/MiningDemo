/** This is an automatically generated class by FairyGUI. Please do not modify it. **/
var Main;
(function (Main) {
    var MainBinder = (function () {
        function MainBinder() {
        }
        MainBinder.bindAll = function () {
            fairygui.UIObjectFactory.setPackageItemExtension(Main.UI_CommonBtn.URL, Main.UI_CommonBtn);
            fairygui.UIObjectFactory.setPackageItemExtension(Main.UI_FlashEffect.URL, Main.UI_FlashEffect);
            fairygui.UIObjectFactory.setPackageItemExtension(Main.UI_ShopWindow.URL, Main.UI_ShopWindow);
            fairygui.UIObjectFactory.setPackageItemExtension(Main.UI_CloseBtn.URL, Main.UI_CloseBtn);
            fairygui.UIObjectFactory.setPackageItemExtension(Main.UI_ShopItem.URL, Main.UI_ShopItem);
            fairygui.UIObjectFactory.setPackageItemExtension(Main.UI_BuyBtn.URL, Main.UI_BuyBtn);
            fairygui.UIObjectFactory.setPackageItemExtension(Main.UI_ShopPanel.URL, Main.UI_ShopPanel);
            fairygui.UIObjectFactory.setPackageItemExtension(Main.UI_Toast.URL, Main.UI_Toast);
            fairygui.UIObjectFactory.setPackageItemExtension(Main.UI_GameUI.URL, Main.UI_GameUI);
            fairygui.UIObjectFactory.setPackageItemExtension(Main.UI_CoinItem.URL, Main.UI_CoinItem);
            fairygui.UIObjectFactory.setPackageItemExtension(Main.UI_CoinMinItem.URL, Main.UI_CoinMinItem);
            fairygui.UIObjectFactory.setPackageItemExtension(Main.UI_SurePanel.URL, Main.UI_SurePanel);
        };
        return MainBinder;
    }());
    Main.MainBinder = MainBinder;
})(Main || (Main = {}));
//# sourceMappingURL=MainBinder.js.map