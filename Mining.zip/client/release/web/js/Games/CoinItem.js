var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* name
*/
var Games;
(function (Games) {
    var CoinItem = (function (_super) {
        __extends(CoinItem, _super);
        function CoinItem() {
            return _super.call(this) || this;
        }
        return CoinItem;
    }(Main.UI_CoinItem));
    Games.CoinItem = CoinItem;
})(Games || (Games = {}));
//# sourceMappingURL=CoinItem.js.map