var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* name
*/
var Games;
(function (Games) {
    var CoinMinItem = (function (_super) {
        __extends(CoinMinItem, _super);
        function CoinMinItem() {
            return _super.call(this) || this;
        }
        return CoinMinItem;
    }(Main.UI_CoinMinItem));
    Games.CoinMinItem = CoinMinItem;
})(Games || (Games = {}));
//# sourceMappingURL=CoinMinItem.js.map