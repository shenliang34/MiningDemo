/**
* name
*/
var Games;
(function (Games) {
    var Road = (function () {
        function Road() {
            this.posList = [];
        }
        return Road;
    }());
    Games.Road = Road;
})(Games || (Games = {}));
//# sourceMappingURL=Road.js.map