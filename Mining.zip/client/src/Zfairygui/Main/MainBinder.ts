/** This is an automatically generated class by FairyGUI. Please do not modify it. **/

module Main {

	export class MainBinder{
		public static bindAll():void {
			fairygui.UIObjectFactory.setPackageItemExtension(UI_CommonBtn.URL, UI_CommonBtn);
			fairygui.UIObjectFactory.setPackageItemExtension(UI_FlashEffect.URL, UI_FlashEffect);
			fairygui.UIObjectFactory.setPackageItemExtension(UI_ShopWindow.URL, UI_ShopWindow);
			fairygui.UIObjectFactory.setPackageItemExtension(UI_CloseBtn.URL, UI_CloseBtn);
			fairygui.UIObjectFactory.setPackageItemExtension(UI_ShopItem.URL, UI_ShopItem);
			fairygui.UIObjectFactory.setPackageItemExtension(UI_BuyBtn.URL, UI_BuyBtn);
			fairygui.UIObjectFactory.setPackageItemExtension(UI_ShopPanel.URL, UI_ShopPanel);
			fairygui.UIObjectFactory.setPackageItemExtension(UI_Toast.URL, UI_Toast);
			fairygui.UIObjectFactory.setPackageItemExtension(UI_GameUI.URL, UI_GameUI);
			fairygui.UIObjectFactory.setPackageItemExtension(UI_CoinItem.URL, UI_CoinItem);
			fairygui.UIObjectFactory.setPackageItemExtension(UI_CoinMinItem.URL, UI_CoinMinItem);
			fairygui.UIObjectFactory.setPackageItemExtension(UI_SurePanel.URL, UI_SurePanel);
		}
	}
}