/**
* name 
*/
module Games
{
	export class CoinItem extends Main.UI_CoinItem
	{
		constructor()
		{
			super();
		}
	}
}