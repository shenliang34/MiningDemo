/**
* name 
*/
module Games
{
	export class Toast extends Main.UI_Toast
	{
		constructor()
		{
			super();
		}
	}
}