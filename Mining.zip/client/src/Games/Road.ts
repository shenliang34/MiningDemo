/**
* name 
*/
module Games
{
	import Point = Laya.Point;
	export class Road
	{
		public posList: Array<Point>;
		constructor()
		{
			this.posList = [];
		}
	}
}