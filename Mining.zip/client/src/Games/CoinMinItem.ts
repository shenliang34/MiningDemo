/**
* name 
*/
module Games
{
	export class CoinMinItem extends Main.UI_CoinMinItem
	{
		constructor()
		{
			super();
		}
	}
}