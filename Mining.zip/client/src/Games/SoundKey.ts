/**
* name 
*/
module Games
{
	export class SoundKey
	{

		public static bag_com: string = "sounds/bag_com.mp3";
		public static car_move: string = "sounds/car_move.mp3";
		public static click_npc: string = "sounds/click_npc.mp3";
		public static wa_guangsu: string = "sounds/wa_guangsu.mp3";
		constructor()
		{

		}
	}
}