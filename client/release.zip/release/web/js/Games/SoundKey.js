/**
* name
*/
var Games;
(function (Games) {
    var SoundKey = /** @class */ (function () {
        function SoundKey() {
        }
        SoundKey.bag_com = "sounds/bag_com.mp3";
        SoundKey.car_move = "sounds/car_move.mp3";
        SoundKey.click_npc = "sounds/click_npc.mp3";
        SoundKey.wa_guangsu = "sounds/wa_guangsu.mp3";
        return SoundKey;
    }());
    Games.SoundKey = SoundKey;
})(Games || (Games = {}));
//# sourceMappingURL=SoundKey.js.map